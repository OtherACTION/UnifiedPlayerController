var a00048 =
[
    [ "JumpInput", "a00048.html#a6a50590fb506e70979bac8602ed4bdc2", null ],
    [ "LookInput", "a00048.html#a3c3f2da525ac8a9ec3666cc92fb640dd", null ],
    [ "MoveInput", "a00048.html#a53822596ebe40b2ada4b14d8d7389962", null ],
    [ "OnApplicationFocus", "a00048.html#a449e1637c537f9bdd7156f19d4ac7e46", null ],
    [ "SetCursorState", "a00048.html#af57df1dc1651d050c155551b3ddd7596", null ],
    [ "SprintInput", "a00048.html#a462333c542673dc427b327bec814efe9", null ],
    [ "analogMovement", "a00048.html#a85ba2c42b54863126077338c72cb074c", null ],
    [ "cursorInputForLook", "a00048.html#aeadc4df0156574c4d9c96d79f3cbf1a8", null ],
    [ "cursorLocked", "a00048.html#ac6211c297e2354c38fbba16ed1dc9700", null ],
    [ "jump", "a00048.html#afbd05777b6a01a37497126139bcc3cc4", null ],
    [ "look", "a00048.html#a3613cd6b4c0946e8757194291a9217de", null ],
    [ "move", "a00048.html#a3b0d7f9967567a6775b366b33257f9dd", null ],
    [ "sprint", "a00048.html#a2fcbbf1cc9dc185d7ebe2e2a42523a79", null ]
];