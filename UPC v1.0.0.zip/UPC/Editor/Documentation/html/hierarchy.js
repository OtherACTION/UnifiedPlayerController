var hierarchy =
[
    [ "EditorWindow", null, [
      [ "UnifiedPlayerController.DocumentationOpener", "a00028.html", null ]
    ] ],
    [ "MonoBehaviour", null, [
      [ "UnifiedPlayerController.BasicRigidBodyPush", "a00040.html", null ],
      [ "UnifiedPlayerController.DynamicFollowHead", "a00032.html", null ],
      [ "UnifiedPlayerController.ThirdPersonCameraZoom", "a00036.html", null ],
      [ "UnifiedPlayerController.UnifiedPlayerController", "a00044.html", null ],
      [ "UnifiedPlayerController.UnifiedPlayerInputs", "a00048.html", null ]
    ] ]
];